﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class Form1 : Form
    {
        string[,] seats = new string[5, 3];
        string[] x = new string[10];
        public Form1()
        {
            InitializeComponent();
        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        private void button17_Click(object sender, EventArgs e)
        {
            if (textBox1.Text == "")
            {
                MessageBox.Show("PLEASE ENTER YOUR NAME");
            }
            if (listBox1.SelectedIndex == 0 && listBox2.SelectedIndex == 0)
            {
                seats[0, 0] = textBox1.Text;
            }

            if (listBox1.SelectedIndex == 0 && listBox2.SelectedIndex == 1)
            {
                seats[0, 1] = textBox1.Text;
            }

            if (listBox1.SelectedIndex == 0 && listBox2.SelectedIndex == 2)
            {
                seats[0, 2] = textBox1.Text;
            }

            if (listBox1.SelectedIndex == 1 && listBox2.SelectedIndex == 0)
            {
                seats[1, 0] = textBox1.Text;
            }

            if (listBox1.SelectedIndex == 1 && listBox2.SelectedIndex == 1)
            {
                seats[1, 1] = textBox1.Text;
            }

            if (listBox1.SelectedIndex == 1 && listBox2.SelectedIndex == 2)
            {
                seats[1, 2] = textBox1.Text;
            }

            if (listBox1.SelectedIndex == 2 && listBox2.SelectedIndex == 0)
            {
                seats[2, 0] = textBox1.Text;
            }

            if (listBox1.SelectedIndex == 2 && listBox2.SelectedIndex == 1)
            {
                seats[2, 1] = textBox1.Text;

            }

            if (listBox1.SelectedIndex == 2 && listBox2.SelectedIndex == 2)
            {
                seats[2, 2] = textBox1.Text;

            }

            if (listBox1.SelectedIndex == 3 && listBox2.SelectedIndex == 0)
            {
                seats[3, 0] = textBox1.Text;
            }

            if (listBox1.SelectedIndex == 3 && listBox2.SelectedIndex == 1)
            {
                seats[3, 1] = textBox1.Text;
            }

            if (listBox1.SelectedIndex == 3 && listBox2.SelectedIndex == 2)
            {
                seats[3, 2] = textBox1.Text;
            }

            if (listBox1.SelectedIndex == 4 && listBox2.SelectedIndex == 0)
            {
                seats[4, 0] = textBox1.Text;
            }

            if (listBox1.SelectedIndex == 4 && listBox2.SelectedIndex == 1)
            {
                seats[4, 1] = textBox1.Text;
            }

            if (listBox1.SelectedIndex == 4 && listBox2.SelectedIndex == 2)
            {
                seats[4, 2] = textBox1.Text;
            }


        }

        private void button20_Click(object sender, EventArgs e)
        {
            richTextBox1.Text = "";
            for (int i = 0; i < 5; i++)
            {
                for (int j = 0; j < 3; j++)
                {
                    richTextBox1.Text += seats[i, j] + "\n";
                }
            }
        }

        private void button22_Click(object sender, EventArgs e)
        {
            for (int i = 0; i < 5; i++)
            {
                for (int j = 0; j < 3; j++)
                {
                    seats[i, j] = "Manpreet";
                }
            }
        }

        private void button18_Click(object sender, EventArgs e)
        {
            if (listBox1.SelectedIndex == 0 && listBox2.SelectedIndex == 0)
            {
                seats[0, 0] = "";
            }

            if (listBox1.SelectedIndex == 0 && listBox2.SelectedIndex == 1)
            {
                seats[0, 1] = "";
            }

            if (listBox1.SelectedIndex == 0 && listBox2.SelectedIndex == 2)
            {
                seats[0, 2] = "";
            }

            if (listBox1.SelectedIndex == 1 && listBox2.SelectedIndex == 0)
            {
                seats[1, 0] = "";
            }

            if (listBox1.SelectedIndex == 1 && listBox2.SelectedIndex == 1)
            {
                seats[1, 1] = "";
            }

            if (listBox1.SelectedIndex == 1 && listBox2.SelectedIndex == 2)
            {
                seats[1, 2] = "";
            }

            if (listBox1.SelectedIndex == 2 && listBox2.SelectedIndex == 0)
            {
                seats[2, 0] = "";
            }

            if (listBox1.SelectedIndex == 2 && listBox2.SelectedIndex == 1)
            {
                seats[2, 1] = "";

            }

            if (listBox1.SelectedIndex == 2 && listBox2.SelectedIndex == 2)
            {
                seats[2, 2] = "";

            }

            if (listBox1.SelectedIndex == 3 && listBox2.SelectedIndex == 0)
            {
                seats[3, 0] = "";
            }

            if (listBox1.SelectedIndex == 3 && listBox2.SelectedIndex == 1)
            {
                seats[3, 1] = "";
            }

            if (listBox1.SelectedIndex == 3 && listBox2.SelectedIndex == 2)
            {
                seats[3, 2] = "";
            }

            if (listBox1.SelectedIndex == 4 && listBox2.SelectedIndex == 0)
            {
                seats[4, 0] = "";
            }

            if (listBox1.SelectedIndex == 4 && listBox2.SelectedIndex == 1)
            {
                seats[4, 1] = "";
            }

            if (listBox1.SelectedIndex == 4 && listBox2.SelectedIndex == 2)
            {
                seats[4, 2] = "";
            }
        }

        private void button19_Click(object sender, EventArgs e)
        {
            try
            {
                for (int i = 0; i < 5; i++)
                {
                    for (int j = 0; j < 3; j++)
                        if (seats[i, j] == "")
                        {
                            /*---EXCEPTION---*/
                        }
                        else
                        {
                            if (x[0] == "")
                            {
                                x[0] = textBox1.Text;
                            }
                            else if (x[1] == "")
                            {
                                x[1] = textBox1.Text;
                            }
                            else if (x[2] == "")
                            {
                                x[2] = textBox1.Text;
                            }
                            else if (w[3] == "")
                            {
                                x[3] = textBox1.Text;
                            }
                            else if (x[4] == "")
                            {
                                x[4] = textBox1.Text;
                            }
                            else if (x[5] == "")
                            {
                                x[5] = textBox1.Text;
                            }
                            else if (x[6] == "")
                            {
                                x[6] = textBox1.Text;
                            }
                            else if (x[7] == "")
                            {
                                x[7] = textBox1.Text;
                            }
                            else if (x[8] == "")
                            {
                                x[8] = textBox1.Text;
                            }
                            else if (x[9] == "")
                            {
                                x[9] = textBox1.Text;
                            }
                        }


                }
            }
            catch (Exception)
            { }
        }
    }
}

